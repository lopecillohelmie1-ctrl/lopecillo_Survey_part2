from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from database import Base, engine
from routers import auth, products

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Veloura")
app.add_middleware(SessionMiddleware, secret_key="change-this-secret-key-for-production")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

app.include_router(auth.router)
app.include_router(products.router)

@app.get("/")
def home(request):
    return products.main_page(request)
