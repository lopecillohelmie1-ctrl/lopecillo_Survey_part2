from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from database import get_db
from models import Product

router = APIRouter()
templates = Jinja2Templates(directory="templates")

def main_page(request: Request):
    from database import SessionLocal
    db = SessionLocal()
    try:
        products = db.query(Product).order_by(Product.id.desc()).all()
        return templates.TemplateResponse("main.html", {
            "request": request,
            "products": products,
            "username": request.session.get("username")
        })
    finally:
        db.close()

@router.post("/products/add")
def add_product(request: Request, name: str = Form(...), price: float = Form(...),
                description: str = Form(...), db: Session = Depends(get_db)):
    user_id = request.session.get("user_id")
    if not user_id:
        return RedirectResponse("/login", status_code=303)
    if price < 0 or not name.strip() or not description.strip():
        return RedirectResponse("/", status_code=303)
    product = Product(name=name.strip(), price=price, description=description.strip(), owner_id=user_id)
    db.add(product)
    db.commit()
    return RedirectResponse("/", status_code=303)

@router.post("/products/{product_id}/delete")
def delete_product(product_id: int, request: Request, db: Session = Depends(get_db)):
    user_id = request.session.get("user_id")
    if not user_id:
        return RedirectResponse("/login", status_code=303)
    product = db.query(Product).filter(Product.id == product_id, Product.owner_id == user_id).first()
    if product:
        db.delete(product)
        db.commit()
    return RedirectResponse("/", status_code=303)
