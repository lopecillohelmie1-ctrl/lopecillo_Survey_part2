# Veloura

A simple product listing website built with FastAPI, APIRouter, SQLAlchemy, and SQLite.

## Features
- Register, login, and logout
- Password hashing with `hashlib.pbkdf2_hmac` (unique random salt per password)
- Exactly two database models: `User` and `Product`
- Add products with name, price, and description
- Remove your own products
- Responsive `main.html` storefront

## Run in VS Code
1. Extract the ZIP file and open the `veloura` folder in VS Code.
2. Open Terminal > New Terminal.
3. Create and activate a virtual environment (Windows):
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```
4. Install packages:
   ```powershell
   pip install -r requirements.txt
   ```
5. Start the app:
   ```powershell
   uvicorn main:app --reload
   ```
6. Open http://127.0.0.1:8000

## GitHub Desktop
1. Open GitHub Desktop.
2. Choose File > Add Local Repository.
3. Select the extracted `veloura` folder.
4. If it is not already a repository, choose the option to create one.
5. Commit your files, then publish the repository if desired.

## Notes
- The SQLite database file `veloura.db` is created automatically on first run.
- For deployment, set a strong secret key using an environment variable and use HTTPS.
- This is a learning project; add CSRF protection, rate limiting, and production configuration before public deployment.
